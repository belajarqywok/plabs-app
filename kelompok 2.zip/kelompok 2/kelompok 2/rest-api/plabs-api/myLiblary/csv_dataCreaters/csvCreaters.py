#!/bin/env python3
import datetime
import pandas as pd
class create:
    def __init__(self,nickname,emailAdd,rating,messages):
        self.file="data.csv"
        self.nickname=nickname
        self.emailAdd=emailAdd
        self.rating=rating
        self.messages=messages
    def goCsv(self):
        sort=[]
        sort.append({
        "date":datetime.datetime.now().strftime("%Y%m%d%H"),
        "nickname":self.nickname,
        "email_address":self.emailAdd,
        "rating":self.rating,
        "messages":self.messages
        })
        df=pd.DataFrame(sort)
        df.to_csv('data.csv', mode='a', index=False, header=False)
        return "ok"