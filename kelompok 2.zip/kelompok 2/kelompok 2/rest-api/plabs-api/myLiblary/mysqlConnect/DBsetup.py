import mysql.connector
class dbsetup:
    def __init__(self):
        self.dbconf={
            'user':"qywok",
            'password':"qywok",
            'host':"0.0.0.0",
            'database':"plabs_users"
        }
        self.con=mysql.connector.connect(**self.dbconf)
        self.cur=self.con.cursor()
    def executed(self):
        self.cur.execute("create table users (no int(20) AUTO_INCREMENT PRIMARY KEY,dates date NOT NULL,nickname char(25) NOT NULL,email_add varchar(50) NOT NULL,rating int(5) NOT NULL,messages varchar(1000));")
        self.con.commit()
print(dbsetup().executed())