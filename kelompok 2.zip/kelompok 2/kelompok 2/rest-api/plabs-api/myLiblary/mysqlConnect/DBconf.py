class dbconf:
    def __init__(self):
        self.username="qywok"
        self.password="qywok"
        self.host="0.0.0.0"
        self.database="plabs_users"