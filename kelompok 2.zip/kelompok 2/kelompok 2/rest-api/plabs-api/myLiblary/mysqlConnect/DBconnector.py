import mysql.connector
import datetime
from myLiblary.mysqlConnect.DBconf import dbconf
class dbsetup:
    def __init__(self,nickname,email_add,rating,messages):
        self.dbconf={
            'user':dbconf().username,
            'password':dbconf().password,
            'host':dbconf().host,
            'database':dbconf().database
        }
        self.nickname=nickname
        self.email_add=email_add
        self.rating=rating
        self.messages=messages
        self.con=mysql.connector.connect(**self.dbconf)
        self.cur=self.con.cursor()
    def addData(self):
        self.cur.execute(f"select * from users where nickname='{self.nickname}'&&email_add='{self.email_add}'&&rating='{self.rating}'&&messages='{self.messages}';")
        if len(self.cur.fetchall()) > 0 :
            return "ok"
        else:
            self.cur.execute("INSERT INTO users VALUES (null,"+'"'+str(datetime.datetime.now().strftime("%Y%m%d%H"))+'"'
                            +","+'"'+self.nickname+'"'
                            +","+'"'+self.email_add+'"'
                            +","+'"'+str(self.rating)+'"'
                            +","+'"'+self.messages+'"'
                            +")"
            )
            self.con.commit()
            return "ok"


