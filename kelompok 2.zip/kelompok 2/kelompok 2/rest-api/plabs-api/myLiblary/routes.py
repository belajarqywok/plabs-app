#!/bin/env python3
from flask_mail import Mail, Message
from flask import Flask, render_template
from flask_json import FlaskJSON,json_response,jsonify
from myLiblary.services.about import about
from myLiblary.mysqlConnect.DBconnector import dbsetup
from myLiblary.csv_dataCreaters.csvCreaters import create
from myLiblary.mailReq.mailConf import conf
app=Flask(__name__)
FlaskJSON(app)
@app.route("/")
def index():
    return render_template("index.html",url="https://instagram.com/qywok_exploiter_357",title="redirect")
@app.route("/feedback/<string:key>/<string:nickname>/<string:emailAdd>/<int:rating>/<string:messages>",methods=["POST","GET"])
def feedback(key,nickname,emailAdd,rating,messages):
    goodResponse="ok"
    if key==about.key:
        if dbsetup(nickname,emailAdd,rating,messages).addData()==goodResponse:
            if create(nickname,emailAdd,rating,messages).goCsv()==goodResponse:
                def send(header,recept,mess):
                    app.config["MAIL_SERVER"]="smtp.gmail.com"
                    app.config["MAIL_PORT"]=465
                    app.config["MAIL_USERNAME"]=conf.account.get("add")
                    app.config["MAIL_PASSWORD"]=conf.account.get("password")
                    app.config["MAIL_USE_TLS"]=False
                    app.config["MAIL_USE_SSL"]=True
                    mail=Mail(app)
                    msg=Message(header,sender=conf.account.get("add"),recipients=[recept])
                    msg.body=mess
                    mail.send(msg)
                def messClass():
                    if rating<=40:
                        send(f"untuk {nickname}",emailAdd,"kami sebagai developer qlabs app minta maaf atas ketidaknyamanannya")
                    elif rating==60|rating==80:
                        send(f"untuk {nickname}",emailAdd,"kami sebagai developer qlabs app ber-terimakasih atas sarannya, kami akan berusaha semaksimal mungkin untuk memperbaiki aplikasi ini kedepannya")
                    elif rating>=100:
                        send(f"untuk {nickname}",emailAdd,"kami sebagai developer qlabs app sangat ber-terimakasih atas sarannya")
                messClass()
                return jsonify({
                                "nickname":nickname,
                                "email_add":emailAdd,
                                "rating":rating,
                                "messages":messages,
                                "status":200
                            })
    else:
        return json_response(status=401)