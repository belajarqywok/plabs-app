class mailConf:
    def __init__(self):
        self.account={
            "add":"qlabsapp.dev@gmail.com",
            "password":"xqE2f&7(#4!"
        }
conf=mailConf()