from myLiblary.mailReq.mailConf import conf
from myLiblary.routes import app
from flask_mail import Mail, Message
class Send:
    def __init__(self,nickname,emailAdd,rating):
        self.nickname=nickname
        self.emailAdd=emailAdd
        self.rating=rating
    def response(self):
        app.config["MAIL_SERVER"]="smtp.gmail.com"
        app.config["MAIL_PORT"]=465
        app.config["MAIL_USERNAME"]=conf.account.get("add")
        app.config["MAIL_PASSWORD"]=conf.account.get("password")
        app.config["MAIL_USE_TLS"]=False
        app.config["MAIL_USE_SSL"]=True
        mail=Mail(app)
        def send(header,senderFrom,recept,mess):
            msg=Message(header,sender=senderFrom,recipients=[recept])
            msg.body=mess
            mail.send(msg)
        if self.rating <= 2:
            send("untuk pengguna qlabs app",conf.account.get("add"),self.emailAdd,f"untuk {self.nickname}, kami sebagai developer minta maaf atas ketidaknyamanannya. kami berusaha semaksimal mungkin untuk memperbarui aplikasi ini")
        elif self.rating==3:
            send("untuk pengguna qlabs app",conf.account.get("add"),self.emailAdd,f"untuk {self.nickname}, kami sebagai developer berterimakasih atas saran yang diberikan")
        elif self.rating>=4:
            send("untuk pengguna qlabs app",conf.account.get("add"),self.emailAdd,f"untuk {self.nickname}, kami sebagai developer berterimakasih atas saran yang diberikan")

