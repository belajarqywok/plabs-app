#!/bin/env python3
import os
class aboutApp:
    def __init__(self):
        self.nameApp="plab-api"
        self.ipAdd="0.0.0.0"
        self.ports=[8080,8888,8000,5001,5002,3000,1000]
        self.key="qywok_exploiter_357"
about=aboutApp()