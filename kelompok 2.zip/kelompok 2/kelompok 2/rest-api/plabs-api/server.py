from myLiblary.routes import app,about
if __name__ == "__main__":
    app.run(host=about.ipAdd,port=about.ports[0])